#ifndef THREAD_H
#define THREAD_H
#include<QThread>
#include<string.h>
#include<mainwindow.h>

using namespace std;




};
#endif // THREAD_H
