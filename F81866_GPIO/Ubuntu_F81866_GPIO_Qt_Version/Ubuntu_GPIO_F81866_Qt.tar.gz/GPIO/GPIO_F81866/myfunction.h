#ifndef MYFUNCTION_H
#define MYFUNCTION_H
#include <string>
using namespace std;





#endif // MYFUNCTION_H
