#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QtConcurrent>
#include<QTimer>
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <stdio.h>
#include <unistd.h>
#include <unistd.h>


using namespace std;

#define EXPORT_PATH             "/sys/class/gpio/export"

#define GPIO_1  80
#define GPIO_3  81
#define GPIO_5  82
#define GPIO_7  83
#define GPIO_4  84
#define GPIO_6  85
#define GPIO_8  86
#define GPIO_10 87

#define GPIO_1_VALUE_PATH       "/sys/class/gpio/gpio80/value"
#define GPIO_3_VALUE_PATH       "/sys/class/gpio/gpio81/value"
#define GPIO_5_VALUE_PATH       "/sys/class/gpio/gpio82/value"
#define GPIO_7_VALUE_PATH       "/sys/class/gpio/gpio83/value"
#define GPIO_4_VALUE_PATH       "/sys/class/gpio/gpio84/value"
#define GPIO_6_VALUE_PATH       "/sys/class/gpio/gpio85/value"
#define GPIO_8_VALUE_PATH       "/sys/class/gpio/gpio86/value"
#define GPIO_10_VALUE_PATH       "/sys/class/gpio/gpio87/value"

#define GPIO_1_DIRECTION_PATH       "/sys/class/gpio/gpio80/direction"
#define GPIO_3_DIRECTION_PATH       "/sys/class/gpio/gpio81/direction"
#define GPIO_5_DIRECTION_PATH       "/sys/class/gpio/gpio82/direction"
#define GPIO_7_DIRECTION_PATH       "/sys/class/gpio/gpio83/direction"
#define GPIO_4_DIRECTION_PATH       "/sys/class/gpio/gpio84/direction"
#define GPIO_6_DIRECTION_PATH       "/sys/class/gpio/gpio85/direction"
#define GPIO_8_DIRECTION_PATH       "/sys/class/gpio/gpio86/direction"
#define GPIO_10_DIRECTION_PATH       "/sys/class/gpio/gpio87/direction"


namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:

    void Init();

    bool isExist(string file_path);

    QString s_to_qs(const string &s);

    void set_GPIO_value(string file_path, int value);

    int get_GPIO_value(string file_path);

    void set_GPIO_direction(string file_path, string direction);

    string get_GPIO_direction(string file_path);

    void value_print();

    void start();

    void Control_GPIO(string file_dirction, string dirction,
                      string file_value, int value, int index);

    void on_OutButton_1_clicked();

    void on_radioButton_1_0_clicked();

    void on_radioButton_1_1_clicked();

    void on_InputButton_1_clicked();

    void on_OutButton_3_clicked();

    void on_radioButton_3_0_clicked();

    void on_radioButton_3_1_clicked();

    void on_InputButton_3_clicked();

    void on_OutButton_5_clicked();

    void on_radioButton_5_0_clicked();

    void on_radioButton_5_1_clicked();

    void on_InputButton_5_clicked();

    void on_OutButton_7_clicked();

    void on_radioButton_7_0_clicked();

    void on_radioButton_7_1_clicked();

    void on_InputButton_7_clicked();

    void on_OutButton_4_clicked();

    void on_radioButton_4_0_clicked();

    void on_radioButton_4_1_clicked();

    void on_InputButton_4_clicked();

    void on_OutButton_6_clicked();

    void on_radioButton_6_0_clicked();

    void on_radioButton_6_1_clicked();

    void on_InputButton_6_clicked();

    void on_OutButton_8_clicked();

    void on_radioButton_8_0_clicked();

    void on_radioButton_8_1_clicked();

    void on_InputButton_8_clicked();

    void on_OutButton_10_clicked();

    void on_radioButton_10_0_clicked();

    void on_radioButton_10_1_clicked();

    void on_InputButton_10_clicked();

    void on_All_Output_0_clicked();

    void on_All_Output_1_clicked();

    void on_All_Input_clicked();

private:
    Ui::MainWindow *ui;
    int FLAG;
};




#endif // MAINWINDOW_H
