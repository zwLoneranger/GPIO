#include "thread.h"
#include<QDebug>
#include<mainwindow.h>
#include "ui_mainwindow.h"
using namespace std;

