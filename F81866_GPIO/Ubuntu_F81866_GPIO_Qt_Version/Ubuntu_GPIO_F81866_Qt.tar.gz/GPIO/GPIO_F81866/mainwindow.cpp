﻿#include "mainwindow.h"
#include "ui_mainwindow.h"

using namespace std;

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->FLAG = 0;
    Init();
}

MainWindow::~MainWindow()
{
    this->FLAG = 0;
    delete ui;

}

void MainWindow::Init()
{
    set_GPIO_value(EXPORT_PATH, GPIO_1);
    set_GPIO_value(EXPORT_PATH, GPIO_3);
    set_GPIO_value(EXPORT_PATH, GPIO_5);
    set_GPIO_value(EXPORT_PATH, GPIO_7);
    set_GPIO_value(EXPORT_PATH, GPIO_4);
    set_GPIO_value(EXPORT_PATH, GPIO_6);
    set_GPIO_value(EXPORT_PATH, GPIO_8);
    set_GPIO_value(EXPORT_PATH, GPIO_10);

    // 2.如果全部文件存在，则输出初始化成功
    if (isExist(GPIO_1_VALUE_PATH)   &&
        isExist(GPIO_3_VALUE_PATH)   &&
        isExist(GPIO_5_VALUE_PATH)   &&
        isExist(GPIO_7_VALUE_PATH)   &&
        isExist(GPIO_4_VALUE_PATH)   &&
        isExist(GPIO_6_VALUE_PATH)   &&
        isExist(GPIO_8_VALUE_PATH)   &&
        isExist(GPIO_10_VALUE_PATH))
    {
        ui->PrintEdit->setText("Sucessfully Initialized !");

        // 3.启动子线程持续监听GPIO的value
        this->FLAG = 1;
        start();
    }else {

        ui->PrintEdit->setStyleSheet("color:red");
        ui->PrintEdit->setText("Init Failure !"
                               " Please check gpio-f7188x driver or F81866 GPIO!");

    }
}

bool MainWindow::isExist(string file_path)
{
    fstream file;
    file.open(file_path, ios::in);
    if(file)
    {
        return true;
    }else {
        return false;
    }
}


QString MainWindow::s_to_qs(const string &s)
{
    return QString(QString::fromLocal8Bit(s.c_str()));
}


void MainWindow::set_GPIO_value(string file_path, int value)
{
    ofstream outfile;
    outfile.open(file_path, ios::out | ios::trunc);
    outfile << value << endl;
    outfile.close();
}


int MainWindow::get_GPIO_value(string file_path)
{
     ifstream infile;
     string line;
     infile.open(file_path);
     getline(infile, line);
     istringstream is(line);
     int i;
     is >> i;
     return i;
}

void MainWindow::set_GPIO_direction(string file_path, string direction)
{
    ofstream outfile;
    outfile.open(file_path, ios::out | ios::trunc);
    outfile << direction << endl;
    outfile.close();
}

string MainWindow::get_GPIO_direction(string file_path)
{
    ifstream infile;
    string line;
    infile.open(file_path);
    getline(infile, line);
    return line;
}

void MainWindow::value_print()
{
    while (this->FLAG) {
        int value_1 = get_GPIO_value(GPIO_1_VALUE_PATH);
        int value_3 = get_GPIO_value(GPIO_3_VALUE_PATH);
        int value_5 = get_GPIO_value(GPIO_5_VALUE_PATH);
        int value_7 = get_GPIO_value(GPIO_7_VALUE_PATH);
        int value_4 = get_GPIO_value(GPIO_4_VALUE_PATH);
        int value_6 = get_GPIO_value(GPIO_6_VALUE_PATH);
        int value_8 = get_GPIO_value(GPIO_8_VALUE_PATH);
        int value_10 = get_GPIO_value(GPIO_10_VALUE_PATH);

        ui->lineEdit_1->setText(QString::number(value_1));
        ui->lineEdit_3->setText(QString::number(value_3));
        ui->lineEdit_5->setText(QString::number(value_5));
        ui->lineEdit_7->setText(QString::number(value_7));
        ui->lineEdit_4->setText(QString::number(value_4));
        ui->lineEdit_6->setText(QString::number(value_6));
        ui->lineEdit_8->setText(QString::number(value_8));
        ui->lineEdit_10->setText(QString::number(value_10));
    }
}


void MainWindow::start()
{
     QtConcurrent::run(this,&MainWindow::value_print);
}


void MainWindow::Control_GPIO(string file_dirction, string dirction,string file_value, int value, int index)
{
    stringstream fmt;
    set_GPIO_direction(file_dirction,dirction);
    if(dirction == "out")
    {
        set_GPIO_value(file_value,value);
    }

    string gpio_direction= get_GPIO_direction(file_dirction);
    int int_gpio_value = get_GPIO_value(file_value);
    string gpio_value = to_string(int_gpio_value);
    string array[] = {"1", "3", "5", "7",
                      "4", "6","8", "10"};

    fmt << "Set: Pin " << array[index] << "\t       "
        << "Direction: " << gpio_direction << "\t"
        << "Value: "  <<  gpio_value;

    string print_info = fmt.str();
    QString qs_gpio_dirction = s_to_qs(print_info);
    ui->PrintEdit->setText(qs_gpio_dirction);
}


void MainWindow::on_OutButton_1_clicked()
{
    if(ui->radioButton_1_0->isChecked()){

        Control_GPIO(GPIO_1_DIRECTION_PATH, "out",
                     GPIO_1_VALUE_PATH, 0, 0);

    }else if(ui->radioButton_1_1->isChecked()){

        Control_GPIO(GPIO_1_DIRECTION_PATH, "out",
                     GPIO_1_VALUE_PATH, 1, 0);
    }
}

void MainWindow::on_radioButton_1_0_clicked()
{

}

void MainWindow::on_radioButton_1_1_clicked()
{

}

void MainWindow::on_InputButton_1_clicked()
{

    Control_GPIO(GPIO_1_DIRECTION_PATH, "in",
                 GPIO_1_VALUE_PATH, 1, 0);
}

void MainWindow::on_OutButton_3_clicked()
{
    if(ui->radioButton_3_0->isChecked()){

        Control_GPIO(GPIO_3_DIRECTION_PATH, "out",
                     GPIO_3_VALUE_PATH, 0, 1);


    }else if(ui->radioButton_3_1->isChecked()){

        Control_GPIO(GPIO_3_DIRECTION_PATH, "out",
                     GPIO_3_VALUE_PATH, 1, 1);
    }
}

void MainWindow::on_radioButton_3_0_clicked()
{

}

void MainWindow::on_radioButton_3_1_clicked()
{

}

void MainWindow::on_InputButton_3_clicked()
{
    Control_GPIO(GPIO_3_DIRECTION_PATH, "in",
                 GPIO_3_VALUE_PATH, 1, 1);
}

void MainWindow::on_OutButton_5_clicked()
{

    if(ui->radioButton_5_0->isChecked()){

        Control_GPIO(GPIO_5_DIRECTION_PATH, "out",
                     GPIO_5_VALUE_PATH, 0, 2);


    }else if(ui->radioButton_5_1->isChecked()){

        Control_GPIO(GPIO_5_DIRECTION_PATH, "out",
                     GPIO_5_VALUE_PATH, 1, 2);

    }
}

void MainWindow::on_radioButton_5_0_clicked()
{

}

void MainWindow::on_radioButton_5_1_clicked()
{

}

void MainWindow::on_InputButton_5_clicked()
{
    Control_GPIO(GPIO_5_DIRECTION_PATH, "in",
                 GPIO_5_VALUE_PATH, 1, 2);
}

void MainWindow::on_OutButton_7_clicked()
{
    if(ui->radioButton_7_0->isChecked()){

        Control_GPIO(GPIO_7_DIRECTION_PATH, "out",
                     GPIO_7_VALUE_PATH, 0, 3);


    }else if(ui->radioButton_7_1->isChecked()){

        Control_GPIO(GPIO_7_DIRECTION_PATH, "out",
                     GPIO_7_VALUE_PATH, 1, 3);
    }
}

void MainWindow::on_radioButton_7_0_clicked()
{

}

void MainWindow::on_radioButton_7_1_clicked()
{

}

void MainWindow::on_InputButton_7_clicked()
{
    Control_GPIO(GPIO_7_DIRECTION_PATH, "in",
                 GPIO_7_VALUE_PATH, 1, 3);
}

void MainWindow::on_OutButton_4_clicked()
{
    if(ui->radioButton_4_0->isChecked()){

        Control_GPIO(GPIO_4_DIRECTION_PATH, "out",
                     GPIO_4_VALUE_PATH, 0, 4);

    }else if(ui->radioButton_4_1->isChecked()){

        Control_GPIO(GPIO_4_DIRECTION_PATH, "out",
                     GPIO_4_VALUE_PATH, 1, 4);
    }
}

void MainWindow::on_radioButton_4_0_clicked()
{

}

void MainWindow::on_radioButton_4_1_clicked()
{

}

void MainWindow::on_InputButton_4_clicked()
{
    Control_GPIO(GPIO_4_DIRECTION_PATH, "in",
                 GPIO_4_VALUE_PATH, 1, 4);
}

void MainWindow::on_OutButton_6_clicked()
{
    if(ui->radioButton_6_0->isChecked()){

        Control_GPIO(GPIO_6_DIRECTION_PATH, "out",
                     GPIO_6_VALUE_PATH, 0, 5);


    }else if(ui->radioButton_6_1->isChecked()){

        Control_GPIO(GPIO_6_DIRECTION_PATH, "out",
                     GPIO_6_VALUE_PATH, 1, 5);
    }
}

void MainWindow::on_radioButton_6_0_clicked()
{

}

void MainWindow::on_radioButton_6_1_clicked()
{

}

void MainWindow::on_InputButton_6_clicked()
{
    Control_GPIO(GPIO_6_DIRECTION_PATH, "in",
                 GPIO_6_VALUE_PATH, 1, 5);
}


void MainWindow::on_OutButton_8_clicked()
{
    if(ui->radioButton_8_0->isChecked()){

        Control_GPIO(GPIO_8_DIRECTION_PATH, "out",
                     GPIO_8_VALUE_PATH, 0, 6);


    }else if(ui->radioButton_8_1->isChecked()){

        Control_GPIO(GPIO_8_DIRECTION_PATH, "out",
                     GPIO_8_VALUE_PATH, 1, 6);
    }
}

void MainWindow::on_radioButton_8_0_clicked()
{

}

void MainWindow::on_radioButton_8_1_clicked()
{

}

void MainWindow::on_InputButton_8_clicked()
{
    Control_GPIO(GPIO_8_DIRECTION_PATH, "in",
                 GPIO_8_VALUE_PATH, 1, 6);
}

void MainWindow::on_OutButton_10_clicked()
{
    if(ui->radioButton_10_0->isChecked()){

        Control_GPIO(GPIO_10_DIRECTION_PATH, "out",
                     GPIO_10_VALUE_PATH, 0, 7);


    }else if(ui->radioButton_10_1->isChecked()){

        Control_GPIO(GPIO_10_DIRECTION_PATH, "out",
                     GPIO_10_VALUE_PATH, 1, 7);
    }
}

void MainWindow::on_radioButton_10_0_clicked()
{

}

void MainWindow::on_radioButton_10_1_clicked()
{

}

void MainWindow::on_InputButton_10_clicked()
{
    Control_GPIO(GPIO_10_DIRECTION_PATH, "in",
                 GPIO_10_VALUE_PATH, 1, 7);
}


void MainWindow::on_All_Output_0_clicked()
{
    set_GPIO_direction(GPIO_1_DIRECTION_PATH, "out");
    set_GPIO_direction(GPIO_3_DIRECTION_PATH, "out");
    set_GPIO_direction(GPIO_5_DIRECTION_PATH, "out");
    set_GPIO_direction(GPIO_7_DIRECTION_PATH, "out");
    set_GPIO_direction(GPIO_4_DIRECTION_PATH, "out");
    set_GPIO_direction(GPIO_6_DIRECTION_PATH, "out");
    set_GPIO_direction(GPIO_8_DIRECTION_PATH, "out");
    set_GPIO_direction(GPIO_10_DIRECTION_PATH, "out");

    set_GPIO_value(GPIO_1_VALUE_PATH,0);
    set_GPIO_value(GPIO_3_VALUE_PATH,0);
    set_GPIO_value(GPIO_5_VALUE_PATH,0);
    set_GPIO_value(GPIO_7_VALUE_PATH,0);
    set_GPIO_value(GPIO_4_VALUE_PATH,0);
    set_GPIO_value(GPIO_6_VALUE_PATH,0);
    set_GPIO_value(GPIO_8_VALUE_PATH,0);
    set_GPIO_value(GPIO_10_VALUE_PATH,0);

    ui->PrintEdit->setText("All Output 0");
}

void MainWindow::on_All_Output_1_clicked()
{
    set_GPIO_direction(GPIO_1_DIRECTION_PATH, "out");
    set_GPIO_direction(GPIO_3_DIRECTION_PATH, "out");
    set_GPIO_direction(GPIO_5_DIRECTION_PATH, "out");
    set_GPIO_direction(GPIO_7_DIRECTION_PATH, "out");
    set_GPIO_direction(GPIO_4_DIRECTION_PATH, "out");
    set_GPIO_direction(GPIO_6_DIRECTION_PATH, "out");
    set_GPIO_direction(GPIO_8_DIRECTION_PATH, "out");
    set_GPIO_direction(GPIO_10_DIRECTION_PATH, "out");

    set_GPIO_value(GPIO_1_VALUE_PATH,1);
    set_GPIO_value(GPIO_3_VALUE_PATH,1);
    set_GPIO_value(GPIO_5_VALUE_PATH,1);
    set_GPIO_value(GPIO_7_VALUE_PATH,1);
    set_GPIO_value(GPIO_4_VALUE_PATH,1);
    set_GPIO_value(GPIO_6_VALUE_PATH,1);
    set_GPIO_value(GPIO_8_VALUE_PATH,1);
    set_GPIO_value(GPIO_10_VALUE_PATH,1);
    ui->PrintEdit->setText("All Output 1");
}


void MainWindow::on_All_Input_clicked()
{
    set_GPIO_direction(GPIO_1_DIRECTION_PATH, "in");
    set_GPIO_direction(GPIO_3_DIRECTION_PATH, "in");
    set_GPIO_direction(GPIO_5_DIRECTION_PATH, "in");
    set_GPIO_direction(GPIO_7_DIRECTION_PATH, "in");
    set_GPIO_direction(GPIO_4_DIRECTION_PATH, "in");
    set_GPIO_direction(GPIO_6_DIRECTION_PATH, "in");
    set_GPIO_direction(GPIO_8_DIRECTION_PATH, "in");
    set_GPIO_direction(GPIO_10_DIRECTION_PATH, "in");
    ui->PrintEdit->setText("All Input");
}
